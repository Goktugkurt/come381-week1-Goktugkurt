# Otonom Stok Takibi ve Kredi Risk Kontrollü Perakende Veritabanı

Bu proje, bir perakende dükkânının kategori, ürün, tedarikçi, müşteri, sipariş, satış ve raf sensörü kayıtlarını PostgreSQL'de tutar. İki çoktan-çoğa ilişki ara tablolarla çözüldü: `purchase_order_item` (sipariş–ürün) ve `sale_item` (satış–ürün). Tasarım kararı olarak satış anındaki birim fiyat ve maliyet `sale_item` içinde saklanır; fiyat değişse de geçmiş satışların kârı değişmez. Kredi satışında müşteri zorunludur; bu kural `CHECK` ile korunur.

```bash
createdb come381
psql -d come381 -f sql/schema.sql
```

Ödev 1: `docs/er.md`, `sql/schema.sql`. Ödev 2: `week-05/` (çalıştırma sırası `week-05/README.md` içinde). Yapay zeka kullanımı: `AI_LOG.md`.
